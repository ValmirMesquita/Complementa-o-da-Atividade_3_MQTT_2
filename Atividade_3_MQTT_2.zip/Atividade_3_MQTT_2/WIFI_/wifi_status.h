#ifndef WIFI_STATUS_H
#define WIFI_STATUS_H

#include "configura_geral.h"

extern uint8_t status_wifi_rgb;

#endif